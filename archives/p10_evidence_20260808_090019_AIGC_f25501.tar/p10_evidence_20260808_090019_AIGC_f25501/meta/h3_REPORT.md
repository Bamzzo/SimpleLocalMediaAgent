# MiniMax-H3 FL2VA minimal real validation report

Date: 2026-08-07
Scope: Official FL2VA weights + official SGLang cookbook path. NOT SLMAgent E2E.

## Result
- Generation: SUCCESS (attempt 2)
- Output: `/root/autodl-tmp/h3-smoke/out/minimax-h3-fl2va-5s-768p.mp4`
- Video id: `c6eeb25c-82ae-47bf-aee6-4f06142f9d33`
- Resolution: 1344x768 (short edge 768, 16:9)
- Duration (ffprobe): 5.207 s (124 frames @ 24 fps; API seconds field 5.166667)
- Codecs: H.264 video + AAC stereo 32 kHz
- Server bind: `127.0.0.1:30010` (stopped after validation)

## Environment
- Env: `/root/autodl-tmp/envs/minimax-h3-101bb232`
- SGLang: `0.5.17.dev554+g101bb2327` @ `101bb2327cdebf310d5261775f00eaef13a2e168`
- torch: `2.11.0+cu130`; `CUDA_HOME=/root/autodl-tmp/cuda-13.0` (nvcc 13.0.48)
- GPUs: `CUDA_VISIBLE_DEVICES=1,2` (RTX 6000D ~85GB)
- Weights: `/root/autodl-tmp/models/MiniMax-H3` FL2VA-only, 85 files, 144.05 GB @ `bfc8ed0353f5a9733be73e6b2c98ec0948195b86`

## Serve command
```bash
export CUDA_VISIBLE_DEVICES=1,2
export CUDA_HOME=/root/autodl-tmp/cuda-13.0
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:${LD_LIBRARY_PATH:-}"
export HF_HOME=/root/autodl-tmp/hf-cache
export HF_HUB_CACHE=/root/autodl-tmp/hf-cache
sglang serve \
  --model-path /root/autodl-tmp/models/MiniMax-H3 \
  --model-variant fl2va \
  --num-gpus 2 \
  --tp-size 2 \
  --ulysses-degree 1 \
  --performance-mode memory \
  --layerwise-offload-components dit,text_encoder,vae \
  --dit-offload-prefetch-size 1 \
  --dit-layerwise-resident-layers 20 \
  --enable-torch-compile false \
  --host 127.0.0.1 \
  --port 30010
```
(Official cookbook 2×RTX 5090 lossless recipe; host forced to localhost.)

## Request
File: `/root/autodl-tmp/h3-smoke/request_fl2va.json`
- task=fl2va, first+last keyframes, short_edge=768, aspect_ratio=16:9, seconds=5, seed=2101
- Test media: synthetic no-copyright PNGs in `/root/autodl-tmp/h3-smoke/media/` (not official MiniMax samples)

## Resources (real)
- API peak_memory_mb: 23830.0
- API inference_time_s: 796.57
- Wall-clock poll elapsed: 799 s
- Sampler attempt2 peak: GPU1/GPU2 ≈ 28125 MiB each; CPU used ≈ 23631 MiB
- Session peak incl. load: GPU ≈ 37199 MiB each; CPU used ≈ 220105 MiB

## Errors / retries
1. HF download stale refs/main `73372e6` 404 → pin `bfc8ed0`
2. HF XET CDN CAS error @~28GB → `HF_HUB_DISABLE_XET=1` resume → 144.05GB OK
3. Gen attempt1: denoise/decode OK, failed on missing ffprobe → apt install ffmpeg; identical resubmit → SUCCESS

## Artifacts
- `/root/autodl-tmp/h3-smoke/out/` (mp4 + first/last frames)
- `/root/autodl-tmp/h3-smoke/logs/` (serve, download, request, ffprobe)
- `/root/autodl-tmp/h3-smoke/metrics/` (nvidia-smi snapshots, timeseries)

## FLUX readiness
H3 official FL2VA minimal path verified on this host. Can proceed to FLUX validation as a separate track. This is not SLMAgent E2E.
