# FLUX.2 Klein 9B 原生单图烟测报告（P4.1）

## 1. 实验范围

本实验验证的是：**在当前 AutoDL 实例上，使用官方 Diffusers 路径对 `black-forest-labs/FLUX.2-klein-9B`（BF16）做一次且仅一次的原生文本生成图像烟测**。

明确**不属于**本实验：

- 不是 SLMAgent 接入或联调；
- 不是 H3 + FLUX 端到端；
- 不是 Docker 部署；
- 不是图生图 / 多参考编辑 / 批处理 / 并发；
- 不是高分辨率调优、主观画质评测或长期稳定性测试。

---

## 2. 实例与隔离边界

### 已验证事实

| 项 | 值 |
|---|---|
| 系统 | Ubuntu 22.04.5 LTS |
| 内核 | 5.15.0-78-generic |
| NVIDIA 驱动 | 595.71.05 |
| 推理 GPU | GPU 0，NVIDIA RTX 6000D（约 85651 MiB） |
| 主机内存（烟测前快照量级） | 约 754 Gi 总量 |

### 仅适用于当前 AutoDL 实例的配置

FLUX 隔离路径（全部在 `/root/autodl-tmp` 下）：

| 用途 | 绝对路径 |
|---|---|
| 工作根 | `/root/autodl-tmp/flux-smoke/` |
| 独立 Conda 环境 | `/root/autodl-tmp/envs/flux2-klein-9b/` |
| 本地模型目录 | `/root/autodl-tmp/models/FLUX.2-klein-9B/` |
| 独立 HF 缓存 | `/root/autodl-tmp/hf-cache-flux/` |
| 独立 pip 缓存 | `/root/autodl-tmp/pip-cache-flux/` |

### H3 隔离声明（已验证未改动）

全程未修改、未复用、未写入以下 H3 关键路径：

- `/root/autodl-tmp/models/MiniMax-H3`
- `/root/autodl-tmp/envs/minimax-h3*`
- `/root/autodl-tmp/cuda-13.0`
- `/root/autodl-tmp/h3-smoke`
- `/root/autodl-tmp/hf-cache`
- `/root/autodl-tmp/pip-cache`
- `/root/autodl-tmp/sglang`
- `/root/autodl-tmp/minimax-h3`

P4 结束后上述路径 mtime 仍为 2026-08-07，与烟测前一致。

---

## 3. 官方模型、许可与下载

### 已验证事实

| 项 | 值 |
|---|---|
| 模型 ID | `black-forest-labs/FLUX.2-klein-9B` |
| 权重精度 | BF16 |
| 推理框架 | Diffusers `Flux2KleinPipeline` |
| 许可证 | FLUX Non-Commercial License（gated） |
| Hugging Face 授权 | **授权已完成**（网页 gated access；本报告不记录任何凭据） |
| 本地模型路径 | `/root/autodl-tmp/models/FLUX.2-klein-9B` |
| 最终文件数 | **53** |
| 最终总字节数 | **34,722,811,510 B（32.338 GiB）** |

### 下载白名单（Diffusers 原生组件）

已纳入本地目录的范围：

- `model_index.json`
- `transformer/**`
- `text_encoder/**`
- `tokenizer/**`
- `vae/**`
- `scheduler/**`
- `LICENSE.md`、`README.md`、`.gitattributes`

**明确未下载：** `flux-2-klein-9b.safetensors`（重复单文件权重）。

### 下载过程事实

1. **P3**：按白名单下载时遭遇 Hugging Face **XET/CAS** `File reconstruction error`；已保存约 23.21 GiB；缺 `transformer/diffusion_pytorch_model-00001-of-00002.safetensors`。
2. **P3.1**：在**当前 shell 会话级**设置 `HF_HUB_DISABLE_XET=1`，对**同一本地目录**做 HTTPS 断点续传成功，未删除已有有效文件，未切换模型/镜像/变体。

相关证据：

- `/root/autodl-tmp/flux-smoke/evidence/download_verify_p3_final.txt`
- `/root/autodl-tmp/flux-smoke/evidence/weights_file_manifest_p3_final.sha256`
- `/root/autodl-tmp/flux-smoke/logs/hf_download_p3.log`
- `/root/autodl-tmp/flux-smoke/logs/hf_download_p3_retry_https.log`

---

## 4. 环境与依赖

### 已验证事实（环境 `/root/autodl-tmp/envs/flux2-klein-9b`）

| 组件 | 版本 |
|---|---|
| Python | 3.12.13 |
| torch | 2.8.0+cu128 |
| torchvision | 0.23.0+cu128 |
| torchaudio | 2.8.0+cu128 |
| torch.version.cuda（运行时） | 12.8 |
| diffusers | 0.39.0 |
| transformers | 5.14.1 |
| accelerate | 1.14.0 |
| safetensors | 0.8.0 |
| huggingface_hub | 1.27.0 |
| Pillow | 12.2.0 |

P2 验证：`from diffusers import Flux2KleinPipeline` **可导入**；未调用 `from_pretrained` 下载。

证据：

- `/root/autodl-tmp/flux-smoke/evidence/pip-freeze-p2.txt`
- `/root/autodl-tmp/flux-smoke/evidence/verify-p2.txt`

### 重要隔离声明

- 使用 PyTorch 官方 **cu128 wheel** 自带 CUDA 运行时；
- **未复用、未修改** H3 的 `/root/autodl-tmp/cuda-13.0` toolkit；
- **未使用、未修改** H3 conda 环境。

---

## 5. P4 单次真实推理

### 固定参数（已执行，未改动）

| 参数 | 值 |
|---|---|
| GPU | GPU 0（`CUDA_VISIBLE_DEVICES=0`） |
| 加载方式 | 绝对本地路径 + `local_files_only=True` + 离线环境变量 |
| Pipeline | `Flux2KleinPipeline`，`torch_dtype=torch.bfloat16`，`pipe.to("cuda")` |
| prompt | `A cat holding a sign that says hello world` |
| negative prompt | 未传 |
| seed | 0（`torch.Generator(device="cpu").manual_seed(0)`） |
| 尺寸 | 1024 × 1024 |
| steps | 4 |
| guidance_scale | 1.0 |
| 输出 | PNG |

### 结果（已验证）

| 项 | 值 |
|---|---|
| 输出路径 | `/root/autodl-tmp/flux-smoke/outputs/flux2_klein9b_smoke_seed0_1024.png` |
| Pillow | 可打开；**1024×1024**；mode **RGB** |
| 文件字节数 | **1,385,909 B** |
| SHA256 | `de2f3d3072a0da71f678433e13fc089f5b4574db2b9df77175b325ffa1f67895` |
| 墙钟耗时 | **10.470 s**（2026-08-08 13:08:52 → 13:09:02 +08:00） |
| GPU0 峰值显存 | **38,671 MiB** |
| GPU0 峰值利用率 | **100%** |
| 结束后 GPU 0/1/2 显存 | **均为 0 MiB** |
| 残留进程 | **无** FLUX Python 推理进程；**无** H3 服务残留 |

脚本 / 日志 / 证据：

- `/root/autodl-tmp/flux-smoke/scripts/run_flux2_klein9b_smoke.py`
- `/root/autodl-tmp/flux-smoke/requests/flux2_klein9b_smoke_request.json`
- `/root/autodl-tmp/flux-smoke/logs/run_flux2_klein9b_smoke_p4.log`
- `/root/autodl-tmp/flux-smoke/evidence/output_verify_p4.txt`
- `/root/autodl-tmp/flux-smoke/evidence/resource_timeseries_p4.csv`
- `/root/autodl-tmp/flux-smoke/evidence/nvidia_smi_{before,after}_p4.txt`
- `/root/autodl-tmp/flux-smoke/evidence/free_{before,after}_p4.txt`

---

## 6. 已证明与未证明

### 已证明

在**本机当前 AutoDL 实例**、模型 `FLUX.2-klein-9B`、上述软件组合与固定参数下：

- 可从完整本地 Diffusers 权重**离线**加载；
- 可在 GPU 0 上生成**一张真实** 1024×1024 RGB PNG；
- 输出可通过 Pillow 尺寸校验，并具备可复现的 SHA256 记录；
- 烟测后 GPU 与进程可回到空闲，且 H3 资产保持隔离未动。

### 未证明（不得外推）

- 真实 SLMAgent 接入；
- FLUX 与 H3 端到端编排；
- 图生图 / 编辑 / 批量 / 并发；
- 高分辨率；
- 长期稳定性与主观画质；
- Docker 封装与生产服务化。

**上述 10.470 秒墙钟、38,671 MiB 峰值显存等，仅为本次单次烟测观测值，不得写成通用性能承诺。**

---

## 7. 下次恢复与下一阶段建议

### 恢复注意（仅当前实例经验）

- 需要访问 Hugging Face 时：在**新的 shell**中按需 `source /etc/network_turbo`（会话级，勿写入 `.bashrc`）；
- 若再遇 XET/CAS 错误：仅在**当前 shell**设置 `HF_HUB_DISABLE_XET=1` 后对原目录续传；
- **不要在文档、脚本或聊天中写入 Token、登录命令或凭据路径**；授权状态以 Hugging Face 账户侧为准。

### 下一阶段建议（尚未执行）

1. **优先在本地仓库**实现真实后端适配器与契约测试（不依赖云端常驻服务）。
2. 云端下一步再将 FLUX 包装为**仅监听 `127.0.0.1`** 的最小任务服务，经 SSH 隧道与本地 SLMAgent 联调。
3. **首次端到端必须串行**：FLUX 生成首尾帧并释放 GPU 后，再启动 H3 的 5 秒 768p FL2VA。

---

## 8. 结论

P1–P4 在当前实例上完成了与 H3 完全隔离的 FLUX.2 Klein 9B 原生最小验证：**单提示词 → 单张 1024 PNG 离线成功**。  
本报告仅固化事实与边界；不包含凭据，不启动任何服务。
