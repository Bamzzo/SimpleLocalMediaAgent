import torch
import torch.distributed as dist

dist.init_process_group("nccl")
rank = dist.get_rank()

value = torch.tensor([float(rank + 1)], device=f"cuda:{rank}")
dist.all_reduce(value)
torch.cuda.synchronize()

print(
    f"rank={rank}, "
    f"device={torch.cuda.get_device_name(rank)}, "
    f"all_reduce={value.item()}"
)

dist.destroy_process_group()
