SLMAgent 云端 H3 适配备份包
============================
生成时间: 2026-08-07
目录名: slmagent-h3-cloud-adaptation-20260807

这是什么
--------
云端为跑通 MiniMax-H3 FL2VA 官方最小验证，我们所做的适配脚本、环境锁定、
实验日志、成片与校验证据的白名单归档。体积应远小于权重/环境本身。

这不是什么
----------
不是完整 /root/autodl-tmp 镜像；不包含模型权重、完整 Conda 环境、
CUDA Toolkit、HF 缓存、上游完整源码树。详见 EXCLUDE_LIST.txt。

建议保存方式
------------
1) 本机数据盘已有原件；本压缩包用于「拿在手里」备份
2) 下载到你的笔记本/对象存储（AutoDL 文件下载或 scp/rsync）
3) 校验：sha256sum -c 对应的 .sha256 文件
4) GitHub：只提交脚本、文档、脱敏报告与恢复说明；大成片可用 Release/附件或 LFS，
   不要把权重/env/CUDA 推上 Git
5) 云实例释放前：确认本包已下载且哈希校验通过

关键成片
--------
h3-smoke/out/minimax-h3-fl2va-5s-768p.mp4
sha256: 945c220e209e5c68b46c862d34de553becf4316230a4ff91dfa2f6dc94608c40

阅读顺序
--------
1. README.txt（本文件）
2. RESTORE_MANIFEST.txt
3. docs/SESSION_ARCHIVE.txt
4. docs/REPORT.md
5. env-records/ + pins/ + h3-smoke/start_serve.sh
