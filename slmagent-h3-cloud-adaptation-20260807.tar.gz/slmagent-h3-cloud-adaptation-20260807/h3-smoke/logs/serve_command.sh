#!/bin/bash
set -euo pipefail
source /etc/network_turbo || true
source /root/miniconda3/etc/profile.d/conda.sh
conda activate /root/autodl-tmp/envs/minimax-h3-101bb232
export CUDA_HOME=/root/autodl-tmp/cuda-13.0
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:${LD_LIBRARY_PATH:-}"
export HF_HOME=/root/autodl-tmp/hf-cache
export HF_HUB_CACHE=/root/autodl-tmp/hf-cache
export CUDA_VISIBLE_DEVICES=1,2
export PIP_CACHE_DIR=/root/autodl-tmp/pip-cache
cd /root/autodl-tmp/sglang
# Official cookbook: 2×RTX 5090 fastest lossless (SM12 dual-GPU). Bind localhost only.
exec sglang serve \
  --model-path /root/autodl-tmp/models/MiniMax-H3 \
  --model-variant fl2va \
  --num-gpus 2 \
  --tp-size 2 \
  --ulysses-degree 1 \
  --performance-mode memory \
  --layerwise-offload-components dit,text_encoder,vae \
  --dit-offload-prefetch-size 1 \
  --dit-layerwise-resident-layers 20 \
  --enable-torch-compile false \
  --host 127.0.0.1 \
  --port 30010
