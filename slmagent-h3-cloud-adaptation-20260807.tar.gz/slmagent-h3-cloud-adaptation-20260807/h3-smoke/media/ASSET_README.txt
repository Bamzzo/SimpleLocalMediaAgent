These PNG files are synthetic geometric test assets created for MiniMax-H3 FL2VA smoke validation.
They are NOT official MiniMax sample media. No third-party copyrighted imagery is used.
Generated locally on 2026-08-07.
